import http.server
import socketserver
import threading
import time
import smtplib
import logging
from email.mime.text import MIMEText
from huawei_lte_api.Client import Client
from huawei_lte_api.Connection import Connection
from huawei_lte_api.enums.sms import BoxTypeEnum
import json

# --- User Configuration ---
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465
SMTP_SECURE = "ssl"
SMTP_USERNAME = "panduanagani21@gmail.com"
SMTP_APP_PASSWORD = "tagl uewe otqv cefa"
EMAIL_FROM = "panduanagani21@gmail.com"
EMAIL_FROM_NAME = "9493919566"
EMAIL_TO = "vagesh.anagani@gmail.com"
MODEM_IP = '192.168.8.1'
POLL_INTERVAL = 10  # seconds
LOG_FILE = "monitor.log"
# --------------------------

# --- Logging Setup ---
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
# ---------------------

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<title>Modem Status</title>
<meta http-equiv="refresh" content="{refresh_interval}">
<style>
    body {{ font-family: sans-serif; }}
    table {{ border-collapse: collapse; width: 100%; }}
    th, td {{ border: 1px solid #dddddd; text-align: left; padding: 8px; }}
    th {{ background-color: #f2f2f2; }}
    .signal-bars {{ display: flex; align-items: flex-end; height: 20px; }}
    .bar {{ width: 10px; margin-right: 2px; background-color: #ccc; }}
    .bar-1 {{ height: 20%; }}
    .bar-2 {{ height: 40%; }}
    .bar-3 {{ height: 60%; }}
    .bar-4 {{ height: 80%; }}
    .bar-5 {{ height: 100%; }}
    .red {{ background-color: red; }}
    .yellow {{ background-color: yellow; }}
    .green {{ background-color: green; }}
</style>
</head>
<body>
<h1>Modem Status</h1>
<h2>Signal Status</h2>
<div class="signal-bars">
    {signal_bars_html}
</div>
<pre>{signal_status_raw}</pre>
<h2>SMS Messages</h2>
<table>
    <tr>
        <th>Timestamp</th>
        <th>From</th>
        <th>Message</th>
        <th>Emailed</th>
    </tr>
    {sms_messages_html}
</table>
</body>
</html>
"""

modem_data = {
    "signal_status": {},
    "sms_messages": [],
}

def get_signal_strength(rsrp):
    try:
        rsrp = int(rsrp.replace('dBm', ''))
        if rsrp >= -80:
            return 5
        elif rsrp >= -90:
            return 4
        elif rsrp >= -100:
            return 3
        elif rsrp >= -110:
            return 2
        else:
            return 1
    except (ValueError, AttributeError):
        return 0
        
def get_signal_color(strength):
    if strength >= 4:
        return 'green'
    elif strength >= 3:
        return 'yellow'
    else:
        return 'red'

def get_modem_data():
    global modem_data
    try:
        logging.info("Attempting to connect to modem...")
        with Connection(f'http://{MODEM_IP}/') as connection:
            client = Client(connection)
            logging.info("Connected to modem successfully.")

            logging.info("Fetching signal status...")
            status = client.device.signal()
            modem_data["signal_status"] = status
            logging.info(f"Signal status: {status}")

            logging.info("Fetching SMS messages...")
            messages = client.sms.get_sms_list(box_type=BoxTypeEnum.LOCAL_INBOX)
            logging.info("SMS messages fetched.")

            processed_messages = []
            if 'Messages' in messages and 'Message' in messages['Messages']:
                for message in messages['Messages']['Message']:
                    emailed = message['Smstat'] == '0' # Emailed if unread
                    processed_messages.append({
                        "timestamp": message['Date'],
                        "from": message['Phone'],
                        "message": message['Content'],
                        "emailed": "Yes" if emailed else "No"
                    })
                    if emailed:
                        logging.info(f"New unread message from {message['Phone']}")
                        send_email(f"New SMS from {message['Phone']}", message['Content'])
                        client.sms.set_read(message['Index'])
                        logging.info(f"Marked message {message['Index']} as read.")
            
            # Sort messages by timestamp descending
            processed_messages.sort(key=lambda x: x['timestamp'], reverse=True)
            modem_data["sms_messages"] = processed_messages


    except Exception as e:
        error_message = f"An error occurred: {e}"
        logging.exception(error_message)
        modem_data["signal_status"] = {"error": error_message}
        modem_data["sms_messages"] = []

def send_email(subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = f"{EMAIL_FROM_NAME} <{EMAIL_FROM}>"
    msg['To'] = EMAIL_TO

    try:
        logging.info(f"Sending email to {EMAIL_TO}")
        if SMTP_SECURE == "ssl":
            with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT) as server:
                server.login(SMTP_USERNAME, SMTP_APP_PASSWORD)
                server.send_message(msg)
        elif SMTP_SECURE == "tls":
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(SMTP_USERNAME, SMTP_APP_PASSWORD)
                server.send_message(msg)
        logging.info(f"Email sent successfully to {EMAIL_TO}")
    except Exception as e:
        logging.exception(f"Failed to send email: {e}")

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        logging.info(f"Received GET request for {self.path}")
        if self.path == '/':
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()

            # Signal bars
            signal_strength = get_signal_strength(modem_data['signal_status'].get('rsrp'))
            signal_color = get_signal_color(signal_strength)
            signal_bars_html = ''
            for i in range(1, 6):
                bar_class = f'bar bar-{i}'
                if i <= signal_strength:
                    bar_class += f' {signal_color}'
                signal_bars_html += f'<div class="{bar_class}"></div>'

            # SMS messages
            sms_messages_html = ''
            for msg in modem_data['sms_messages']:
                sms_messages_html += f"<tr><td>{msg['timestamp']}</td><td>{msg['from']}</td><td>{msg['message']}</td><td>{msg['emailed']}</td></tr>"

            html = HTML_TEMPLATE.format(
                refresh_interval=POLL_INTERVAL,
                signal_bars_html=signal_bars_html,
                signal_status_raw=json.dumps(modem_data['signal_status'], indent=4),
                sms_messages_html=sms_messages_html
            )
            self.wfile.write(html.encode('utf-8'))
        else:
            self.send_error(404, "Not Found")

def run_web_server():
    PORT = 8888
    with socketserver.TCPServer(("0.0.0.0", PORT), CustomHandler) as httpd:
        logging.info(f"Serving at port {PORT}")
        httpd.serve_forever()

if __name__ == "__main__":
    web_server_thread = threading.Thread(target=run_web_server)
    web_server_thread.daemon = True
    web_server_thread.start()
    logging.info("Web server started in a background thread.")

    while True:
        try:
            get_modem_data()
            time.sleep(POLL_INTERVAL)
        except Exception as e:
            logging.critical(f"Main loop crashed: {e}")
            break