# Dongle Monitor

This script monitors a Huawei E3372 dongle, provides a web interface to view its status and SMS messages, and forwards new SMS messages to a configured email address.

## Requirements

*   Python 3
*   pip for Python 3
*   git
*   `bsd-mailx` (for email notifications from the service)

## Git Repositories

This project relies on the following open-source library:

*   **huawei-lte-api:** [https://github.com/Salamek/huawei-lte-api](https://github.com/Salamek/huawei-lte-api)

## Compatible Drivers and Tools

While this script uses the `huawei_lte_api` library, there are other tools and libraries available for interacting with Huawei dongles. During the development of this script, the following were also considered:

*   **huawei-modem-api-client:** Another Python library for interacting with Huawei modems. It was not used in this project due to some issues with its package structure and documentation.
*   **Gammu:** A command-line utility and library for managing mobile devices. It is a more general-purpose tool and can be more complex to set up.

The `huawei_lte_api` library was chosen for its simplicity and direct focus on the Huawei LTE API.

## Setup

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd dongle-monitor
    ```

2.  **Create a virtual environment:**
    ```bash
    python3 -m venv venv
    ```

3.  **Install the dependencies:**
    ```bash
    venv/bin/pip3 install -r requirements.txt
    ```

4.  **Install `bsd-mailx`:**
    ```bash
    sudo apt-get update && sudo apt-get install -y bsd-mailx
    ```

5.  **Configure the script:**
    Open `dongle_monitor.py` and edit the following user configuration variables:
    ```python
    # --- User Configuration ---
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 465
    SMTP_SECURE = "ssl"
    SMTP_USERNAME = "your_email@gmail.com"
    SMTP_APP_PASSWORD = "your_app_password"
    EMAIL_FROM = "your_email@gmail.com"
    EMAIL_FROM_NAME = "Dongle"
    EMAIL_TO = "recipient_email@example.com"
    MODEM_IP = '192.168.8.1'
    POLL_INTERVAL = 10  # seconds
    LOG_FILE = "monitor.log"
    # --------------------------
    ```

6.  **Set up the systemd service:**
    *   Edit the `dongle_monitor.service` file to ensure the paths and username are correct for your system.
    *   Move the service file to the systemd directory:
        ```bash
        sudo mv dongle_monitor.service /etc/systemd/system/
        ```
    *   Reload the systemd daemon:
        ```bash
        sudo systemctl daemon-reload
        ```

## Usage

### Managing the Service

The script is managed by `systemd`.

*   **Start the service:**
    ```bash
    sudo systemctl start dongle_monitor.service
    ```
*   **Stop the service:**
    ```bash
    sudo systemctl stop dongle_monitor.service
    ```
*   **Check the status:**
    ```bash
    systemctl status dongle_monitor.service
    ```
*   **Enable the service to start on boot:**
    ```bash
    sudo systemctl enable dongle_monitor.service
    ```
*   **Disable the service from starting on boot:**
    ```bash
    sudo systemctl disable dongle_monitor.service
    ```

### Web Interface

The web interface is accessible at `http://<your_raspberry_pi_ip>:8888`.

### Logs

The log file for the script is located at `/home/kali/dongle_monitor/monitor.log`. You can view its contents with:
```bash
cat /home/kali/dongle_monitor/monitor.log
```

Or for real-time logs:
```bash
tail -f /home/kali/dongle_monitor/monitor.log
```
The systemd service logs can be viewed with:
```bash
journalctl -u dongle_monitor.service -f
```

## Troubleshooting

*   **"Address already in use" error:** This error means that the port the web server is trying to use is already in use by another process. You can either stop the other process or change the `PORT` variable in `dongle_monitor.py` to a different port.
*   **Service fails to start:** If the service fails to start, check the logs for errors using `journalctl -u dongle_monitor.service -b`.

## Future Improvements

*   **More advanced web interface:** The web interface could be improved with features like sending SMS messages, viewing more detailed device information, and a more modern design.
*   **Support for more dongle models:** The script could be extended to support other models of Huawei dongles or even dongles from other manufacturers.
*   **API for external integrations:** An API could be added to allow other applications to get data from the dongle.